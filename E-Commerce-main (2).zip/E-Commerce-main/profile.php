<?php
session_start();
include './init.php';
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$host = 'localhost'; 
$dbname = 'a_store';
$username_db = 'root'; 
$password_db = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

$username = $_SESSION['username'];
$error_message = '';
$success_message = '';

// Manejo de la actualización del perfil
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update') {
    $new_username = $_POST['username'];
    $new_password = $_POST['password'];

    // Actualizar la información del usuario
    $stmt = $pdo->prepare("UPDATE admin SET username = :new_username, password = :new_password WHERE username = :username");
    $stmt->bindParam(':new_username', $new_username);
    $stmt->bindParam(':new_password', $new_password);
    $stmt->bindParam(':username', $username);
    
    if ($stmt->execute()) {
        $success_message = "Perfil actualizado con éxito.";
        $_SESSION['username'] = $new_username; // Actualiza el nombre de usuario en la sesión
    } else {
        $error_message = "Error al actualizar el perfil.";
    }
}

// Manejo de la eliminación del usuario
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete') {
    // Eliminar el usuario actual de la base de datos
    $stmt = $pdo->prepare("DELETE FROM admin WHERE username = :username");
    $stmt->bindParam(':username', $username);
    
    if ($stmt->execute()) {
        session_destroy(); // Destruir la sesión actual
        header('Location: index.php'); // Redirigir a la página de inicio 
        exit();
    } else {
        $error_message = "Error al eliminar el usuario.";
    }
}

// Obtener los datos actuales del usuario
$stmt = $pdo->prepare("SELECT * FROM admin WHERE username = :username");
$stmt->bindParam(':username', $username);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Perfil</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

    <div class="container">
        <h2 class="my-4">Modificar Perfil</h2>

        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <!-- Formulario para actualizar perfil -->
        <form action="profile.php" method="POST">
            <div class="form-group">
                <label for="username">Nuevo nombre de usuario:</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
            </div>
            <div class="form-group">
                <label for="password">Nueva contraseña:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary" name="action" value="update">Actualizar Perfil</button>
        </form>
        
        <!-- Formulario para eliminar usuario -->
        <form action="profile.php" method="POST" style="margin-top: 20px;">
            <button type="submit" class="btn btn-danger" name="action" value="delete" onclick="return confirm('¿Estás seguro de que quieres eliminar este usuario?');">Eliminar Usuario</button>
        </form>
    </div>
</body>
</html>
