<?php
$pageTitle = 'Shop';
include './init.php';

// Verificar si la sesión ya está iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$host = 'localhost'; 
$dbname = 'a_store';
$username_db = 'root'; 
$password_db = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = :username AND password = :password");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $_SESSION['username'] = $username;
            
        
            header('Location: index.php');
            exit();
        } else {
            $error_message = "Usuario o contraseña incorrectos.";
        }
        
    } elseif (isset($_POST['register'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];

        if ($password !== $password_confirm) {
            $error_message = "Las contraseñas no coinciden.";
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin WHERE username = :username");
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $userExists = $stmt->fetchColumn();

            if ($userExists) {
                $error_message = "El nombre de usuario ya está en uso.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO admin (username, password) VALUES (:username, :password)");
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':password', $password);
                if ($stmt->execute()) {
                    $success_message = "Registro exitoso. Ahora puedes iniciar sesión.";
                } else {
                    $error_message = "Error al registrar el usuario. Inténtalo de nuevo.";
                }
            }
        }
    } elseif (isset($_POST['logout'])) {
        // Cerrar sesión
        session_unset();
        session_destroy();
        header('Location: login.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión o Registrarse</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <?php if (isset($_SESSION['username'])): ?>
                    <h3 class="text-center">Hola, <?php echo $_SESSION['username']; ?></h3>
                    <form action="login.php" method="POST">
                        <button type="submit" class="btn btn-danger btn-block" name="logout">Cerrar Sesión</button>
                    </form>
                <?php else: ?>
                    <h3 class="text-center">Iniciar Sesión</h3>
                    <?php if ($error_message): ?>
                        <div class="alert alert-danger">
                            <?php echo $error_message; ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success">
                            <?php echo $success_message; ?>
                        </div>
                    <?php endif; ?>
                    <form action="login.php" method="POST">
                        <div class="form-group">
                            <label for="username">Usuario:</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Contraseña:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" name="login">Iniciar Sesión</button>
                        <div class="form-group text-center">
                            <a href="register.php">Crear cuenta</a>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>

<?php include $tpl . 'footer.php'; ?>
