<?php
$navbarItems = [
  
  'Shop' => 'index.php',
  'FAQ' => 'faq.php',
  'Tracking' => 'tracking.php',
  'Contact Us' => 'contact.php'
];
$faqItems = [
  [
    'question' => '¿Ofrecen reembolsos para productos digitales?',
    'answer' => 'Desafortunadamente, no ofrecemos reembolsos para productos digitales debido a su naturaleza. Por favor, asegúrate de revisar la descripción y especificaciones del producto antes de realizar una compra.'
  ],
  [
    'question' => '¿Qué opciones de soporte están disponibles?',
    'answer' => 'Ofrecemos soporte integral para nuestros productos. Si tienes alguna pregunta o problema, puedes contactar a nuestro equipo de soporte por correo electrónico o a través de nuestro portal de clientes.'
  ],
  [
    'question' => '¿Sus productos vienen con garantías?',
    'answer' => 'Sí, cada uno de nuestros productos viene con su propia garantía. Los detalles específicos de la garantía se pueden encontrar en la documentación del producto o en la página del producto.'
  ],
  [
    'question' => '¿Qué métodos de pago aceptan?',
    'answer' => 'Aceptamos varios métodos de pago, incluyendo efectivo, tarjetas de crédito y transferencias bancarias. Puedes elegir el método que mejor se adapte a ti al realizar una compra.'
  ],
  [
    'question' => '¿Ofrecen pago contra entrega?',
    'answer' => 'Sí, ofrecemos el servicio de pago contra entrega a nuestros clientes. Puedes recibir tu pedido y realizar el pago por los productos al momento de la entrega en la dirección especificada.'
  ],
  [
    'question' => '¿Cuáles son las opciones de pago disponibles para los clientes?',
    'answer' => 'Ofrecemos múltiples opciones de pago convenientes para los clientes, incluyendo pago en efectivo, tarjetas de crédito, transferencias bancarias y PayPal. Puedes elegir el método que mejor se adapte a tus preferencias y necesidades.'
  ],
  [
    'question' => '¿Puedo usar una tarjeta de crédito para el pago?',
    'answer' => 'Sí, puedes usar tus tarjetas de crédito para realizar el pago. Aceptamos tarjetas de crédito comúnmente usadas como Visa, MasterCard, American Express, y más.'
  ],



];

