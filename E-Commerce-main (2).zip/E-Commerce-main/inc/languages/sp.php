<?php
$lang = [
  'Luffy Store' => 'Luffy Store',
  'Ltr' => 'Ltr',
  'Sp' => 'sp',
  'Bootstrap' => 'bootstrap.min.css',
  'English' => 'Inglés',
  'Español' => 'Español',
  'Shop' => 'Tienda',
  'FAQ' => 'Preguntas',
  'Tracking' => 'Seguimiento',
  'Contact Us' => 'Contáctanos',
  'Search' => 'Buscar',
  'Login' => 'Inicio Sesion',
  'Logout'=> 'Cerrar Sesion',
  'Said Lagauit Store' => 'Tienda Luffy Store',
  'Last Products' => 'Tienda',
  'Profile' => 'Perfil',
  '' => ''
];