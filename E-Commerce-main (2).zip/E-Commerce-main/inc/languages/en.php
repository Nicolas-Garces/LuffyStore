<?php
$lang = [
  'Luffy Store' => 'Luffy Store',
  'Ltr' => 'Ltr',
  'Sp' => 'sp',
  'Bootstrap' => 'bootstrap.min.css',
  'English' => 'English',
  'Español' => 'Español',
  'Shop' => 'Shop',
  'FAQ' => 'Questions',
  'Tracking' => 'Tracking',
  'Contact Us' => 'Contact',
  'Search' => 'Search',
  'Login' => 'Login',
  'Logout'=> 'Logout',
  'Last Products' => 'Tienda',
  'Profile' => 'Perfil',
  '' => ''
];
