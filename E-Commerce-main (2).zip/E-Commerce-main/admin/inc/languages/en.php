<?php
$lang = array ();
?>