<?php
include './init.php';
session_start();


// Configuración de la base de datos
$host = 'localhost'; // Cambia esto si es necesario
$dbname = 'a_store';
$username_db = 'root'; // Cambia esto según tu configuración
$password_db = ''; // Cambia esto según tu configuración

try {
    // Conexión a la base de datos usando PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        // Iniciar sesión
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Consulta para verificar el usuario y la contraseña
        $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = :username AND password = :password");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // El usuario ha sido verificado
            $_SESSION['username'] = $username;
            header('Location: index.php'); // Redirigir a index.php
            exit();
        } else {
            $error_message = "Usuario o contraseña incorrectos.";
        }
    } elseif (isset($_POST['register'])) {
        // Registro de nuevo usuario
        $username = $_POST['username'];
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];

        if ($password !== $password_confirm) {
            $error_message = "Las contraseñas no coinciden.";
        } else {
            // Verificar si el usuario ya existe
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM admin WHERE username = :username");
            $stmt->bindParam(':username', $username);
            $stmt->execute();
            $userExists = $stmt->fetchColumn();

            if ($userExists) {
                $error_message = "El nombre de usuario ya está en uso.";
            } else {
                // Registrar el nuevo usuario (sin encriptar la contraseña)
                $stmt = $pdo->prepare("INSERT INTO admin (username, password) VALUES (:username, :password)");
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':password', $password);
                if ($stmt->execute()) {
                    $success_message = "Registro exitoso. Ahora puedes iniciar sesión.";
                } else {
                    $error_message = "Error al registrar el usuario. Inténtalo de nuevo.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión o Registrarse</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <h3 class="text-center"></h3>
                <?php if ($error_message): ?>
                    <div class="alert alert-danger">
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($success_message)): ?>
                    <div class="alert alert-success">
                        <?php echo $success_message; ?>
                    </div>
                <?php endif; ?>
                </div>
        </div>
        <div class="row justify-content-center mt-5">
            <div class="col-md-4">
                <h3 class="text-center">Registrarse</h3>
                <form action="login.php" method="POST">
                    <div class="form-group">
                        <label for="register-username">Usuario:</label>
                        <input type="text" class="form-control" id="register-username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="register-password">Contraseña:</label>
                        <input type="password" class="form-control" id="register-password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="password_confirm">Confirmar Contraseña:</label>
                        <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                    </div>
                    <button type="submit" class="btn btn-success btn-block" name="register">Registrarse</button>
                </form>
                
            </div>
        </div>
    </div>

</body>

</html>
<?php include $tpl . 'footer.php';?>
